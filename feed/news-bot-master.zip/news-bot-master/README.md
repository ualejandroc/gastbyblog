# News Bot for chat Platform

> Bots are *hot*.

Here's a bot which lets you use your chat clients ([Telegram](https://telegram.org/) and [Facebook Messenger](http://messenger.com/) currently supported) as a feed reader. You can use our instance directly, but you can also deploy your own version!

* [start with Telegram](https://telegram.me/superfeedr_bot)
* [start with Facebook](https://www.messenger.com/t/superfeedr)

## Features

For now, it's very basic and lets you subscribe, unsubscribe and list feeds to which you're subscribed.
Everytime a feed updates, you get a message.

## Deploy

Please, [see this blog post](https://blog.superfeedr.com/rss-bot-telegram-lambda/).

