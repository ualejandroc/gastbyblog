var querystring = require('querystring')
var url = require('url')
var https = require('https')

var ChatBot = {
  config: {
    baseUrl: '',
    superfeedr: {
      login: '',
      token: ''
    },
    telegram: {
      auth: ''
    },
    facebook: {
      token: ''
    }
  },
  commands: {
  },
  responses: {
  },
  platforms: {
  },
  superfeedr: {
  }
}
