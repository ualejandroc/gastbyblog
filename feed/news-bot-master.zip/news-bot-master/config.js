ChatBot.config.baseUrl = '' // The base URL for your webhook interface
ChatBot.config.superfeedr.login = 'telegraphbot' // superfeedr login
ChatBot.config.superfeedr.token = '' // superfeedr token with subscribe, unsubsribe, list, retrieve rights
ChatBot.config.telegram.auth = '' // auth string for your telegram bot 'id:token'
ChatBot.config.facebook.token =  '' // Facebook token
